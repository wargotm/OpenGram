package org.telegram.ui;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.telegram.messenger.AndroidUtilities;
import org.telegram.messenger.LocaleController;
import org.telegram.messenger.R;
import org.telegram.ui.ActionBar.ActionBar;
import org.telegram.ui.ActionBar.BaseFragment;
import org.telegram.ui.ActionBar.Theme;
import org.telegram.ui.Components.LayoutHelper;

/** Single OpenGram entry in Settings; individual OpenGram options are listed inside. */
public class OpenGramSettingsActivity extends BaseFragment {

    @Override
    protected boolean useSimpleActionBar() {
        return true;
    }

    @Override
    public View createView(Context context) {
        setHasOwnBackground(true);
        simpleActionBar.setBackButtonImage(R.drawable.ic_ab_back);
        simpleActionBar.setTitle(LocaleController.getString(R.string.OpenGramSettings));
        simpleActionBar.setActionBarMenuOnItemClick(new ActionBar.ActionBarMenuOnItemClick() {
            @Override
            public void onItemClick(int id) {
                if (id == -1) finishFragment();
            }
        });

        LinearLayout content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, AndroidUtilities.dp(12), 0, 0);

        content.addView(row(context, LocaleController.getString(R.string.OpenGramGlassSettings),
                () -> presentFragment(new OpenGramGlassSettingsActivity())),
                LayoutHelper.createLinear(LayoutHelper.MATCH_PARENT, 56));
        content.addView(row(context, LocaleController.getString(R.string.OpenGramVerifiedSettings),
                () -> presentFragment(new OpenGramVerifiedSettingsActivity())),
                LayoutHelper.createLinear(LayoutHelper.MATCH_PARENT, 56));

        fragmentView = content;
        return fragmentView;
    }

    private TextView row(Context context, String text, Runnable onClick) {
        TextView tv = new TextView(context);
        tv.setText(text);
        tv.setTextSize(16);
        tv.setGravity(Gravity.CENTER_VERTICAL);
        tv.setPadding(AndroidUtilities.dp(22), 0, AndroidUtilities.dp(22), 0);
        tv.setTextColor(Theme.getColor(Theme.key_windowBackgroundWhiteBlackText));
        tv.setBackground(Theme.createSelectorDrawable(Theme.getColor(Theme.key_listSelector), 2));
        tv.setOnClickListener(v -> onClick.run());
        return tv;
    }
}
