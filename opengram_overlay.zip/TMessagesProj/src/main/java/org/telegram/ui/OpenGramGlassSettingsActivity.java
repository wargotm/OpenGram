package org.telegram.ui;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;

import org.telegram.messenger.AndroidUtilities;
import org.telegram.messenger.MessagesController;
import org.telegram.messenger.LocaleController;
import org.telegram.messenger.R;
import org.telegram.ui.ActionBar.ActionBar;
import org.telegram.ui.ActionBar.BaseFragment;
import org.telegram.ui.ActionBar.Theme;
import org.telegram.ui.Components.LayoutHelper;

/** OpenGram controls for the transparency of Liquid Glass surfaces. */
public class OpenGramGlassSettingsActivity extends BaseFragment {

    private static final String PREF_KEY = "opengram_glass_opacity";
    private static final int DEFAULT_OPACITY = 78;
    private TextView valueView;
    private View previewGlass;
    private SeekBar seekBar;

    @Override
    protected boolean useSimpleActionBar() {
        return true;
    }

    @Override
    public View createView(Context context) {
        setHasOwnBackground(true);
        simpleActionBar.setBackButtonImage(R.drawable.ic_ab_back);
        simpleActionBar.setTitle(LocaleController.getString(R.string.OpenGramGlassSettings));
        simpleActionBar.setActionBarMenuOnItemClick(new ActionBar.ActionBarMenuOnItemClick() {
            @Override
            public void onItemClick(int id) {
                if (id == -1) finishFragment();
            }
        });

        SharedPreferences prefs = MessagesController.getGlobalMainSettings();
        int opacity = Math.max(0, Math.min(100, prefs.getInt(PREF_KEY, DEFAULT_OPACITY)));

        LinearLayout content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(AndroidUtilities.dp(22), AndroidUtilities.dp(28), AndroidUtilities.dp(22), AndroidUtilities.dp(24));

        TextView title = new TextView(context);
        title.setText(LocaleController.getString(R.string.OpenGramGlassOpacity));
        title.setTextSize(17);
        title.setTypeface(AndroidUtilities.bold());
        title.setTextColor(Theme.getColor(Theme.key_windowBackgroundWhiteBlackText));
        content.addView(title, LayoutHelper.createLinear(LayoutHelper.MATCH_PARENT, LayoutHelper.WRAP_CONTENT));

        valueView = new TextView(context);
        valueView.setTextSize(28);
        valueView.setTypeface(AndroidUtilities.bold());
        valueView.setTextColor(Theme.getColor(Theme.key_windowBackgroundWhiteBlueText));
        valueView.setGravity(Gravity.CENTER);
        valueView.setText(opacity + "%");
        content.addView(valueView, LayoutHelper.createLinear(LayoutHelper.MATCH_PARENT, 54, 0, 12, 0, 4));

        seekBar = new SeekBar(context);
        seekBar.setMax(100);
        seekBar.setProgress(opacity);
        content.addView(seekBar, LayoutHelper.createLinear(LayoutHelper.MATCH_PARENT, 44, 0, 2, 0, 0));

        TextView lowHigh = new TextView(context);
        lowHigh.setText(LocaleController.getString(R.string.OpenGramGlassScale));
        lowHigh.setTextSize(13);
        lowHigh.setTextColor(Theme.getColor(Theme.key_windowBackgroundWhiteGrayText));
        content.addView(lowHigh, LayoutHelper.createLinear(LayoutHelper.MATCH_PARENT, LayoutHelper.WRAP_CONTENT, 0, 2, 0, 18));

        TextView previewTitle = new TextView(context);
        previewTitle.setText(LocaleController.getString(R.string.OpenGramGlassPreview));
        previewTitle.setTextSize(15);
        previewTitle.setTypeface(AndroidUtilities.bold());
        previewTitle.setTextColor(Theme.getColor(Theme.key_windowBackgroundWhiteBlackText));
        content.addView(previewTitle, LayoutHelper.createLinear(LayoutHelper.MATCH_PARENT, LayoutHelper.WRAP_CONTENT, 0, 4, 0, 10));

        FrameLayout preview = new FrameLayout(context);
        GradientDrawable previewBackground = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF4779B8, 0xFF8A6AAE, 0xFF4C9B91});
        previewBackground.setCornerRadius(AndroidUtilities.dp(20));
        preview.setBackground(previewBackground);
        TextView sampleText = new TextView(context);
        sampleText.setText(LocaleController.getString(R.string.OpenGramGlassSample));
        sampleText.setTextSize(16);
        sampleText.setTextColor(Color.WHITE);
        sampleText.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams sampleParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, AndroidUtilities.dp(92), Gravity.CENTER);
        preview.addView(sampleText, sampleParams);

        previewGlass = new View(context);
        GradientDrawable glassBackground = new GradientDrawable();
        glassBackground.setColor(0xFFFFFFFF);
        glassBackground.setCornerRadius(AndroidUtilities.dp(18));
        previewGlass.setBackground(glassBackground);
        FrameLayout.LayoutParams glassParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, AndroidUtilities.dp(66), Gravity.CENTER);
        glassParams.leftMargin = AndroidUtilities.dp(14);
        glassParams.rightMargin = AndroidUtilities.dp(14);
        preview.addView(previewGlass, glassParams);
        sampleText.bringToFront();
        content.addView(preview, LayoutHelper.createLinear(LayoutHelper.MATCH_PARENT, 118, 0, 0, 0, 0));

        TextView info = new TextView(context);
        info.setText(LocaleController.getString(R.string.OpenGramGlassInfo));
        info.setTextSize(13);
        info.setTextColor(Theme.getColor(Theme.key_windowBackgroundWhiteGrayText));
        content.addView(info, LayoutHelper.createLinear(LayoutHelper.MATCH_PARENT, LayoutHelper.WRAP_CONTENT, 0, 16, 0, 0));

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                valueView.setText(progress + "%");
                previewGlass.setAlpha(progress / 100f);
                if (fromUser) {
                    prefs.edit().putInt(PREF_KEY, progress).apply();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        });
        previewGlass.setAlpha(opacity / 100f);

        fragmentView = content;
        return fragmentView;
    }
}
