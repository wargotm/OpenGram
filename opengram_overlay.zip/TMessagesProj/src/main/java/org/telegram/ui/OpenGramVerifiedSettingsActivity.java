package org.telegram.ui;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import org.telegram.messenger.AndroidUtilities;
import org.telegram.messenger.MessagesController;
import org.telegram.messenger.LocaleController;
import org.telegram.messenger.NotificationCenter;
import org.telegram.messenger.R;
import org.telegram.messenger.UserConfig;
import org.telegram.tgnet.TLRPC;
import org.telegram.ui.ActionBar.ActionBar;
import org.telegram.ui.ActionBar.BaseFragment;
import org.telegram.ui.ActionBar.Theme;
import org.telegram.ui.Components.LayoutHelper;

/** Local "Major" verification badge for the current account. */
public class OpenGramVerifiedSettingsActivity extends BaseFragment {

    public static String key(int account) {
        return "opengram_major_badge_" + account;
    }

    public static boolean isEnabled(int account) {
        return MessagesController.getGlobalMainSettings().getBoolean(key(account), false);
    }

    @Override
    protected boolean useSimpleActionBar() {
        return true;
    }

    @Override
    public View createView(Context context) {
        setHasOwnBackground(true);
        simpleActionBar.setBackButtonImage(R.drawable.ic_ab_back);
        simpleActionBar.setTitle(LocaleController.getString(R.string.OpenGramVerifiedSettings));
        simpleActionBar.setActionBarMenuOnItemClick(new ActionBar.ActionBarMenuOnItemClick() {
            @Override
            public void onItemClick(int id) {
                if (id == -1) finishFragment();
            }
        });

        SharedPreferences prefs = MessagesController.getGlobalMainSettings();

        LinearLayout content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(AndroidUtilities.dp(22), AndroidUtilities.dp(20), AndroidUtilities.dp(22), 0);

        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(context);
        title.setText(LocaleController.getString(R.string.OpenGramVerifiedMajor));
        title.setTextSize(16);
        title.setTextColor(Theme.getColor(Theme.key_windowBackgroundWhiteBlackText));
        row.addView(title, LayoutHelper.createLinear(0, LayoutHelper.WRAP_CONTENT, 1f));
        Switch toggle = new Switch(context);
        toggle.setChecked(isEnabled(currentAccount));
        row.addView(toggle, LayoutHelper.createLinear(LayoutHelper.WRAP_CONTENT, LayoutHelper.WRAP_CONTENT));
        content.addView(row, LayoutHelper.createLinear(LayoutHelper.MATCH_PARENT, 56));

        TextView info = new TextView(context);
        info.setText(LocaleController.getString(R.string.OpenGramVerifiedInfo));
        info.setTextSize(13);
        info.setTextColor(Theme.getColor(Theme.key_windowBackgroundWhiteGrayText));
        content.addView(info, LayoutHelper.createLinear(LayoutHelper.MATCH_PARENT, LayoutHelper.WRAP_CONTENT, 0, 8, 0, 0));

        toggle.setOnCheckedChangeListener((b, checked) -> {
            prefs.edit().putBoolean(key(currentAccount), checked).apply();
            TLRPC.User self = UserConfig.getInstance(currentAccount).getCurrentUser();
            if (self != null) {
                self.verified = checked;
                TLRPC.User cached = getMessagesController().getUser(self.id);
                if (cached != null) cached.verified = checked;
            }
            getNotificationCenter().postNotificationName(NotificationCenter.mainUserInfoChanged);
            getNotificationCenter().postNotificationName(NotificationCenter.updateInterfaces, MessagesController.UPDATE_MASK_NAME);
        });

        fragmentView = content;
        return fragmentView;
    }
}
